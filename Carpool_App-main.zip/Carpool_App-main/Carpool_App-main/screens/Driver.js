import React, { useEffect } from 'react'
import { StyleSheet, Alert,Button,Text, View } from 'react-native'

const Driver = () => {

   
    return (


        <View style={{flex : 1,justifyContent:'center', alignItems : 'center'}}>
          <Text style = {{fontSize : 30}}>Driver View</Text>
         
          
        </View>
    )
}

export default Driver